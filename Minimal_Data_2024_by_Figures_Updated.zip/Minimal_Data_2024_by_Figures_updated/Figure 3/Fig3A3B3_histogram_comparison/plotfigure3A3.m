clc;
clear all;

data=[8.2	10.3
15.1	3.5
10.9	13.2
16	64.7
11.9	-3.6
19.5	47.7
20.7	-42
20.4	24.6
23.8	12.1
12.3	196
    ];

t=[1 2];

figure (1)
plot(t, data(1,:), 'b','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(2,:), 'g','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(3,:), 'b','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(4,:), 'g','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(5,:), 'b','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(6,:), 'g','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(7,:), 'b','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(8,:), 'g','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(9,:),'b','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(10,:), 'g','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on

axis([0.9,2.1,-60,200]);

title ('Histogram comparison','FontSize',20,'FontName','times new roman');
ylabel('Relative change (%)');

set(gca,'FontName','Times New Roman','FontSize',20,'XTick',[1 2],...
    'XTickLabel',{'Microscopy','Flowcytometry '},'YTick',...
    [-100 -75 -50 -25 0 25 50 75 100 125 150 175 200]);
set(gcf, 'Position', [0, 0, 550, 450]);
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');
box off
