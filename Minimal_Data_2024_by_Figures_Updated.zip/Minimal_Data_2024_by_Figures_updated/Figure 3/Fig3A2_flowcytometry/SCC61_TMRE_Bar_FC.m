SCC61TMRETreatIR=readtable('SCC61_TMRE_Treat IR.xls');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



R1 = table2array(SCC61TMRETreatIR((1:4),3));
R2 = table2array(SCC61TMRETreatIR((5:8),3));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Combine data into a single vector and create a grouping variable
data_mean = [mean(R1), mean(R2)];
sem_mean = [std(R1) / sqrt(length(R1)), ...
              std(R2) / sqrt(length(R2))];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)

% Perform Student's t-test
[h, p, ci, stats] = ttest2(R1, R2);

% Display the t-test results
disp('Two-sample t-test Results:');
disp(['p-value: ', num2str(p)]);
disp(['t-statistic: ', num2str(stats.tstat)]);
disp(['Degrees of freedom: ', num2str(stats.df)]);
disp(['Confidence Interval: ', num2str(ci')]);

%Create a bar chart with error bars
bar(1, data_mean(1), 'FaceColor', 'k','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(2, data_mean(2), 'FaceColor', 'r','FaceAlpha', 0.8,'BarWidth', 0.6);
errorbar(1, data_mean(1), sem_mean(1), 'k', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(2, data_mean(2), sem_mean(2), 'r', 'linestyle', 'none', 'LineWidth', 1.5);


% Customize the plot
set(gca, 'XTick', 1:2, 'XTickLabel', {'0 Gy', '4 Gy'}, 'FontName', 'Times New Roman', 'FontSize', 16, 'XColor', 'k', 'YColor', 'k','XTickLabelRotation', 45);
ylabel('Intensity', 'FontName', 'Times New Roman', 'FontSize', 22, 'Color', 'k');


% yticks([ 50, 75,100]);
ylim([10000 31000]);
% % Display t-test results in the figure
text(1.5, data_mean(1) + 1700, sprintf('p = %0.1e', p), 'FontSize', 20,'FontName', 'Times New Roman','HorizontalAlignment', 'center', 'Color', 'k');
set(gcf, 'Position', [0, 0, 280, 250]);
hold off;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Quantitative Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Standard Deviation 
Std_devi = [std(R1/(max(R1))) , std(R2/(max(R2))) ];
Std_devi_percent = Std_devi*100;
fprintf('Normalized  Percent Standard Deviation %.2f%%\n', Std_devi_percent);

% Mean changes 
mean1 = mean(R1);
mean2 = mean(R2);
mean_change = ((mean2 - mean1) / mean1) * 100;
fprintf('Mean Change: %.2f%%\n', mean_change);