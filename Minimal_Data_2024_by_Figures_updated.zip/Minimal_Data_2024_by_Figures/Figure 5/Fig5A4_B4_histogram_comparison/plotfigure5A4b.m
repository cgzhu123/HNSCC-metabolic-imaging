clc;
clear all;

data=[5	6.5
9.3	11.1
-11	-9.2
13.1	9.5
-8.8	-12.3
15	20.9
-11.8	14.9
10.5	20
-23	-10.2
-17.2	14.8
    ];

t=[1 2];

figure (1)
plot(t, data(1,:), 'b','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(2,:), 'g','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(3,:), 'b','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(4,:), 'g','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(5,:), 'b','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(6,:), 'g','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(7,:), 'b','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(8,:), 'g','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(9,:),'b','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(10,:), 'g','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on

axis([0.9,2.1,-30,50]);

title ('Histogram comparison','FontSize',20,'FontName','times new roman');
ylabel('Relative change (%)');

set(gca,'FontName','Times New Roman','FontSize',20,'XTick',[1 2],...
    'XTickLabel',{'Microscopy','Flowcytometry '},'YTick',...
    [-25 0 25 50 ]);
set(gcf, 'Position', [0, 0, 550, 450]);
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');

box off
