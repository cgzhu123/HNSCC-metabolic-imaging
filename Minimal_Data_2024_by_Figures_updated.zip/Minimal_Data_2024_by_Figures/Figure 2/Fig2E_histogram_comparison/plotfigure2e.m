
clc;
clear all;

data=[9.6	8.4
14.7	7.7
62.9	98.9
-3.1	-2.9
58.3	105.3
-7.6	-9.8
57	143.4
-11.3	-42
119.4	134.6
-26.5	38.7
    ];

t=[1 2];

figure (1)
plot(t, data(1,:), 'b','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(2,:), 'g','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(3,:), 'b','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(4,:), 'g','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(5,:), 'b','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(6,:), 'g','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(7,:), 'b','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(8,:), 'g','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(9,:),'b','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(10,:), 'g','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on

axis([0.9,2.1,-60,150]);

title ('Histogram comparison','FontSize',20,'FontName','times new roman');
ylabel('Relative change (%)');

set(gca,'FontName','Times New Roman','FontSize',20,'XTick',[1 2],...
    'XTickLabel',{'Microscopy','Flowcytometry '},'YTick',...
    [-100 -75 -50 -25 0 25 50 75 100 125 150]);
set(gcf, 'Position', [0, 0, 550, 450]);
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');

box off
