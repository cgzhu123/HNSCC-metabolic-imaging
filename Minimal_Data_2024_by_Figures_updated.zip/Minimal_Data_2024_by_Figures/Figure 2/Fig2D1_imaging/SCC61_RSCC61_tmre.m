clc;
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Load the first CSV file
data1 = readtable('SCC_61_0_Gy.csv');

% Load the second CSV file
data2 = readtable('RSCC_61_0_Gy.csv');

% Extract the third column values
thirdColumn1 = data1{:, 3};
thirdColumn2 = data2{:, 3};

% Display the third column values
disp('Third column values ');
disp(thirdColumn1);

disp('Third column values');
disp(thirdColumn2);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot Kernel Density (Frequency Plot)
figure (1);
hold on;
[f1, xi1] = ksdensity(thirdColumn1 * 255);
plot(xi1, f1, 'LineWidth', 2, 'Color', 'k');
[f2, xi2] =  ksdensity(thirdColumn2 * 255);
plot(xi2, f2, 'LineWidth', 2, 'Color', 'r');
hold off;


% Set font properties for labels and title
xlabel('Intensity', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
ylabel('Probability Density', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
%title('SCC61_ 2-NBDG', 'FontName', 'Arial', 'FontSize', 18);
legend({'SCC-61', 'rSCC-61'}, 'FontSize', 18, 'Location', 'northeast'); % Position the legend in the northeast corner

box on
yticks([ 0,0.0075 0.015]);
%xticks([ 0,100,200]);


% Adjust figure as needed
set(gca, 'FontName', 'Arial', 'FontSize', 20, 'XColor', 'k', 'YColor', 'k'); % Customize axes font and color
set(gcf, 'Position', [0, 0, 550, 450]);

% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(3)
% Combine data into a single vector and create a grouping variable
data_mean = [mean(thirdColumn1 * 255), mean(thirdColumn2 * 255)];
sem_mean = [std(thirdColumn1 * 255) / sqrt(length(thirdColumn1 * 255)), ...
              std(thirdColumn2 * 255) / sqrt(length(thirdColumn2 * 255))];

% Perform Student's t-test
[h, p, ci, stats] = ttest2((thirdColumn1 * 255), (thirdColumn2 * 255));

% Display the t-test results
disp('Two-sample t-test Results:');
disp(['p-value: ', num2str(p)]);
disp(['t-statistic: ', num2str(stats.tstat)]);
disp(['Degrees of freedom: ', num2str(stats.df)]);
disp(['Confidence Interval: ', num2str(ci')]);

%Create a bar chart with error bars
bar(1, data_mean(1), 'FaceColor', 'k','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(2, data_mean(2), 'FaceColor', 'r','FaceAlpha', 0.8,'BarWidth', 0.6);
errorbar(1, data_mean(1), sem_mean(1), 'k', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(2, data_mean(2), sem_mean(2), 'r', 'linestyle', 'none', 'LineWidth', 1.5);


% Customize the plot
set(gca, 'XTick', 1:2, 'XTickLabel', {'SCC-61', 'rSCC-61'}, 'FontName', 'Arial', 'FontSize', 16, 'XColor', 'k', 'YColor', 'k','XTickLabelRotation', 45);
ylabel('Intensity', 'FontName', 'Arial', 'FontSize', 22, 'Color', 'k');


yticks([ 40, 80,120]);
ylim([40 135]);
% % Display t-test results in the figure
text(1.5, data_mean(1) + 15, sprintf('p = %0.1e', p), 'FontSize', 20, 'HorizontalAlignment', 'center', 'Color', 'k');
set(gcf, 'Position', [0, 0, 280, 250]);
hold off;
% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Quantitative Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Standard Deviation 
Std_devi = [std(thirdColumn1) , std(thirdColumn2) ];
Std_devi_percent = Std_devi*100;
fprintf('Normalized  Percent Standard Deviation %.2f%%\n', Std_devi_percent);

% Mean changes 
mean1 = mean(data_mean(1,1));
mean2 = mean(data_mean(1,2));
mean_change = ((mean2 - mean1) / mean1) * 100;
fprintf('Mean Change: %.2f%%\n', mean_change);

% Median changes 

median1 = median(thirdColumn1);
median2 = median(thirdColumn2);
median_change = ((median2 - median1) / median1) * 100;
fprintf('Median Change: %.2f%%\n', median_change);


%Peak Location changes

[peak1, idx1] = max(f1);
peak_location1 = xi1(idx1);
[peak2, idx2] = max(f2);
peak_location2 = xi2(idx2);

% Percentage change in peak Location
peak_change = ((peak_location2 - peak_location1) / peak_location1) * 100;

fprintf('Peak Location Change: %.2f\n%%',peak_change);


% FWHM intensity Changes

fwhm1 = computeFWHM(xi1, f1);
fwhm2 = computeFWHM(xi2, f2);

fwhm_change = ((fwhm2 - fwhm1) / fwhm1) * 100;

fprintf('FWHM Change: %.2f%%\n', fwhm_change);

% Function to compute FWHM
function fwhm = computeFWHM(x, f)
    half_max = max(f) / 2;
    above_half_max = f >= half_max;
    edges = find(diff(above_half_max));
    if length(edges) == 2
        fwhm = x(edges(2)+1) - x(edges(1)); % Width at half max
    else
        fwhm = NaN; % Unable to calculate
    end
end






